import webscrape_mod as webscraper
from datetime import date

# Get's the date for today

today = date.today()

# Declare and initialize local variables with webscraper class, using soup to find the html elements

tableOne = webscraper.cryptoScraper.soup.findAll('p', attrs={'class': 'sc-1eb5slv-0 iJjGCS'})
tableTwo = webscraper.cryptoScraper.soup.findAll('div', attrs={'class': 'sc-131di3y-0 cLgOOr'})
tableThree = webscraper.cryptoScraper.soup2.findAll('span', attrs={'class': 'mobile-price-change'})
tableFour = webscraper.cryptoScraper.soup.findAll('span', attrs={'class': 'sc-1ow4cwt-1 ieFnWP'})
tableFive = webscraper.cryptoScraper.soup.findAll('p', attrs={'class': 'sc-1eb5slv-0 kDEzev font_weight_500___2Lmmi'})
tableSix = webscraper.cryptoScraper.soup.findAll('p', attrs={'class': 'sc-1eb5slv-0 hNpJqV'})

# Set two counters with value at 0

counterX = 0
counterY = 0

# Declare local array variables

cryptoName = []
cryptoDayPrice = []
cryptoDayPercentChange = []
cryptoMarketCap = []
cryptoVolume = []
cryptoCirculationSupply = []

# Start for loop, this will web scrape our data from the html elements and will put it into the array variables

# For loop to append all crypto names to cryptoName array
for rowOne in tableOne:
    cryptoName.append(rowOne.text)
# For loop to append all crypto daily prices to cryptoDayPrice array
for rowTwo in tableTwo:
    cryptoDayPrice.append(rowTwo.text)
# For loop to append all crypto percent change within 24 hours to cryptoPercentChange array
for rowThree in tableThree:
    cryptoDayPercentChange.append(rowThree.text)
# For loop to append all crypto market cap prices to cryptoMarketCap array
for rowFour in tableFour:
    cryptoMarketCap.append(rowFour.text)
# For loop to append all crypto volumes to cryptoVolume array
for rowFive in tableFive:
    cryptoVolume.append(rowFive.text)
# For loop to append all crypto circulation supply to cryptoCirculationSupply array
for rowSix in tableSix:
    cryptoCirculationSupply.append(rowSix.text)

# Open the file to write to text file

f = open("results.txt", "a")

# Start writing to file

f.write(",--------------------------------------------------------Beginning of Record----------------------------------------------------------------\n")

# Start while loop to only include the top five crypto currencies and not all of them
while(counterY<5):

    # CounterX is so that we can see the one at the beginning

    counterX += 1

    # Declare local variables and take out values that had commas and other character symbols so we can calculate our results better

    cryptoDayP = str(cryptoDayPrice[counterY])
    cryptoDayP = cryptoDayP.replace(',', '')
    cryptoDayP = cryptoDayP.replace('$', '')
    cryptoMarketC = str(cryptoMarketCap[counterY])
    cryptoMarketC = cryptoMarketC.replace(',', '')
    cryptoMarketC = cryptoMarketC.replace('$', '')
    cryptoVol = str(cryptoVolume[counterY])
    cryptoVol = cryptoVol.replace(',', '')
    cryptoVol = cryptoVol.replace('$', '')
    cryptoCirc = str(cryptoCirculationSupply[counterY])
    cryptoCirc = cryptoCirc.replace(',', '')
    cryptoPercentC = cryptoDayPercentChange[counterY]
    cryptoPercentC = cryptoPercentC.replace('%', '')

    # Output the web scrape data

    print(str(counterX) + " | " + cryptoName[counterY] + " | " + cryptoDayP + " | " + cryptoPercentC
          + " | " + cryptoMarketC + " | "
          + cryptoVol + " | " + cryptoCirc + " | " + "Date Recorded:" + str(today))

    # Write data to csv file

    writeFile = "," + str(counterX) + "," + cryptoName[counterY] + "," + cryptoDayP + "," + cryptoPercentC + "," + cryptoMarketC + "," + cryptoVol + "," + cryptoCirc + "," + str(today) +  "\n"

    f.write(writeFile)

    # Increment counterY by 1

    counterY += 1

    # Write file end of record

f.write(",------------------------------------------------------------End of Record------------------------------------------------------------------\n")

# Close file

f.close()