import requests
from bs4 import BeautifulSoup

# Create cryptoScraper class for our webscraper program

class cryptoScraper:

    # URL for requests

    URL = "https://coinmarketcap.com/"
    URL2 = "https://coincodex.com/"

    r2 = requests.get(URL2)
    r = requests.get(URL)

    # Use soup to grab data from the URL GET results

    soup = BeautifulSoup(r.content,'html5lib')
    soup2 = BeautifulSoup(r2.content, 'html5lib')