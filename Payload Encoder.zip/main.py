# Includes modules and custom payload function
import sys
import payloadfunctions as payload
from pyfiglet import Figlet

print('-------------------------------------------------------------------')
custom_fig = Figlet(font='graffiti')
print(custom_fig.renderText('plencoder'))
print('\t\tby: C@pt@1nZ3r0\n')
print('-------------------------------------------------------------------\n')

# Main starts the main portion of the program
if __name__ == '__main__':
    if len(sys.argv) <= 1:
        print("Please specify an argument and payload to encode and obscure your payload...\n"
              "(-help for more information on options....)")
    elif sys.argv[1] == "-help":
        print("python3 encodedpayload.py -encode hex -payload \"put your payload in quotes\"")
        print("(-encode options: url, url-bash, base64, hex)")
    elif len(sys.argv) < 5 or len(sys.argv) >= 6:
        print("Please enter the correct arguments, enter -help to learn more....")
    else:
        # Executes the function encodeType
        payload.encodeType(sys.argv[2],sys.argv[4])