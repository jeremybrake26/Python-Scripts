# Define functions for the payload encoder
import base64
import sys
import urllib.parse
import pyperclip as pc

'''
encodeType function is the function behind encoding payloads with hex, url encoding, base64, and url/bash space encoding
'''
def encodeType(encodeType,payloadType):
    if sys.argv[1] == "-encode" and sys.argv[3] == "-payload" and encodeType == "base64":
        translatePayloadAscii = payloadType.encode("ascii")
        translatePayloadEncode = base64.b64encode(translatePayloadAscii)
        createEncodedPayload = translatePayloadEncode.decode("utf-8")
        pc.copy(createEncodedPayload)
    elif sys.argv[1] == "-encode" and sys.argv[3] == "-payload" and encodeType == "url":
        createEncodedPayload = urllib.parse.quote(payloadType)
        pc.copy(createEncodedPayload)
    elif sys.argv[1] == "-encode" and sys.argv[3] == "-payload" and encodeType == "hex":
        translatePayloadEncode = payloadType.encode('utf-8')
        createEncodedPayload = translatePayloadEncode.hex()
        pc.copy(createEncodedPayload)
    elif sys.argv[1] == "-encode" and sys.argv[3] == "-payload" and encodeType == "url-bash":
        payloadType = payloadType.replace(" ","${IFS}")
        createEncodedPayload = urllib.parse.quote(payloadType)
        pc.copy(createEncodedPayload)
    else:
        createEncodedPayload = "Please enter the correct arguments...."
    # returns the encoded payload
    return print(f'Encoded Payload: {createEncodedPayload}')